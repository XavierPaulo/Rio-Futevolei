// Golpes do Modo Tilt — dados puros, editados no Editor de golpes (aba "Modo Tilt").
//
// ground / air: a bola de cada botão no chão e no ar
//   A (□ no PS, X no Xbox) · B (○ no PS, B no Xbox)
//   name   nome da bola (aparece no aviso da pausa)
//   dist   distância (m) do atleta ao centro da área, na direção da seta
//   radius raio (m) da área onde a bola cai (a Precisão do atleta encolhe)
//   apex   altura máxima (m) · model / pace: modelo físico e velocidade da bola (como nos golpes)
//   angle  (só air.A) ângulo de saída em graus: a altura máxima sai dele e da distância
//   air.B  vai direto para a região do parceiro (sem pausa e sem seta; radius = metade do diâmetro)
// names: nome do golpe em cada toque (1, 2, 3), no chão e no ar, por botão
// specials: especiais que os atletas podem escolher na seleção
//   attack  = □ □ (dois toques rápidos) · defense = ○ ○ — precisam da barra cheia
export default {
  "ground": {
    "A": {
      "name": "Bola rápida",
      "dist": 9,
      "radius": 1.7,
      "apex": 2.8,
      "model": "arrasto",
      "pace": "rapida"
    },
    "B": {
      "name": "Bola precisa",
      "dist": 3.6,
      "radius": 0.6,
      "apex": 4.8,
      "model": "backspin",
      "pace": "lenta"
    }
  },
  "air": {
    "A": {
      "name": "Cortada 45°",
      "dist": 9,
      "radius": 1.7,
      "angle": 45,
      "model": "balistica",
      "pace": "rapida"
    },
    "B": {
      "name": "No parceiro",
      "radius": 1,
      "apex": 4.2,
      "model": "backspin",
      "pace": "normal"
    }
  },
  "names": {
    "1": {
      "ground": {
        "A": "Domínio de peito",
        "B": "Domínio de pé"
      },
      "air": {
        "A": "Cabeça",
        "B": "Shark (bloqueio)"
      }
    },
    "2": {
      "ground": {
        "A": "Passe de ombro",
        "B": "Na fita"
      },
      "air": {
        "A": "Ataque de segunda",
        "B": "Levantada de cabeça"
      }
    },
    "3": {
      "ground": {
        "A": "Chute colocado",
        "B": "Pingo"
      },
      "air": {
        "A": "Cabeçada",
        "B": "Shark Attack"
      }
    }
  },
  "specials": {
    "attack": [
      "bicicleta",
      "sharkSupremo",
      "pingoPipoca"
    ],
    "defense": [
      "sarrada",
      "escorpiao",
      "meiaBicicleta"
    ]
  }
};

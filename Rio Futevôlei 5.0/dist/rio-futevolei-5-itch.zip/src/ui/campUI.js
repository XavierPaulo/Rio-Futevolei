// 5.0: telas do Modo Campeonato, do par ou ímpar (início de cada partida e do set decisivo) e do intervalo
// entre sets. Ligadas ao menu do HUD (src/hud.js) pelos ganchos extItems / extHead / extActivate / extClass.
import { CHARACTERS } from '../art/characters.js';
import { faceIcon } from './portraits.js';
import { LEVEL_NAMES, MIN_LEVEL, MAX_LEVEL } from '../difficulty.js';
import { V5 } from '../v5.js';
import { settings, saveSettings } from './settings.js';
import { SLOTS, slotLabel } from '../story/save.js';
import { loadCamp, standings, nextMatch, formatOf, PHASE_NAME, teamName, campAthletes, CAMP, placeName, medal } from '../camp.js';

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const first = id => ((CHARACTERS[id] || { name: id }).name || '').split(' ')[0];
const faces = ids => ids.map(id => `<img class="cp-face" src="${faceIcon(id)}" alt="">`).join('');
const short = ids => ids.map(first).join(' & ');
const money = v => 'R$ ' + Math.round(v || 0).toLocaleString('pt-BR');

// mão do par ou ímpar: n dedos levantados (0 = mão fechada)
export function handSVG(n, flip = false) {
  // dedos na ordem em que se levantam: indicador, médio, anelar, mínimo; o polegar só no 5
  const f = [0, 1, 2, 3].map(i => { const x = 14 + i * 9.5, h = i < n ? 30 : 9; return `<rect x="${x}" y="${34 - h}" width="8" height="${h + 6}" rx="4"/>`; }).join('');
  const thumb = n >= 5 ? '<rect x="2" y="30" width="8" height="24" rx="4" transform="rotate(-30 6 42)"/>' : '<rect x="8" y="40" width="8" height="14" rx="4"/>';
  return `<svg class="hand ${flip ? 'flip' : ''}" viewBox="0 0 60 72" aria-hidden="true"><g fill="#f2c39b" stroke="#1a1622" stroke-width="2.5">${f}${thumb}<rect x="10" y="34" width="42" height="34" rx="12"/></g></svg>`;
}

export function installCampUI(hud) {
  // ---------- par ou ímpar ----------
  // kind: 'match' (início) · 'set3' (sorteio do set decisivo) · 'choice' (2º set: quem perdeu o sorteio escolhe)
  hud.startToss = (m, kind, onDone) => {
    // 5.0: Configurações → Ajudas → Sorteio automático: sem a tela; quem ganha é sorteado (o jogador escolhe sacar)
    if (settings.tossAuto) {
      const winner = kind === 'choice' ? (m.toss ? m.toss.loser : 1) : (Math.random() < 0.5 ? 0 : 1);
      const saca = m.teams[winner].human || Math.random() < +((V5.parOuImpar || {}).cpuSaca ?? 0.7);
      if (kind !== 'choice') m.toss = { winner, loser: 1 - winner };
      onDone(saca ? winner : 1 - winner);
      return;
    }
    const humans = m.teams.filter(t => t.human).map(t => t.id);
    const st = hud.tossSt = { m, kind, onDone, humans, picker: humans.length ? humans[0] : 0, pick: null, nums: {}, numFor: null, winner: null, cpuChoice: null };
    if (kind === 'choice') {
      const chooser = m.toss ? m.toss.loser : 1;
      st.winner = chooser;
      if (!m.teams[chooser].human) st.cpuChoice = Math.random() < +((V5.parOuImpar || {}).cpuSaca ?? 0.7) ? 'sacar' : 'receber';
      hud.open('toss-choice');
      return;
    }
    hud.open('toss');
  };
  const tossNumOrder = st => st.humans.length > 1 ? st.humans : [st.picker];
  const finishToss = (serve) => {
    const st = hud.tossSt; hud.tossSt = null;
    const serveTeam = serve === 'sacar' ? st.winner : 1 - st.winner;
    if (st.kind !== 'choice') st.m.toss = { winner: st.winner, loser: 1 - st.winner };
    hud.close();
    st.onDone(serveTeam);
  };
  const resolveToss = () => {
    const st = hud.tossSt;
    for (const t of [0, 1]) if (!(t in st.nums)) st.nums[t] = Math.floor(Math.random() * 6); // a CPU mostra a mão
    const sum = st.nums[0] + st.nums[1], even = sum % 2 === 0;
    st.winner = (st.pick === 'par') === even ? st.picker : 1 - st.picker;
    if (!st.m.teams[st.winner].human) st.cpuChoice = Math.random() < +((V5.parOuImpar || {}).cpuSaca ?? 0.7) ? 'sacar' : 'receber';
    hud.open('toss-show');
  };
  // ---------- intervalo entre sets ----------
  hud.setBreak = (m, onDone) => { hud.setBreakSt = { m, onDone }; hud.open('set-break'); };

  // ---------- telas ----------
  const tn = (m, t) => m.teams[t].name;
  const who = (m, t) => (m.mode === 'versus' ? `J${t + 1}` : m.teams[t].human ? 'Você' : 'CPU');
  hud.extHead = s => {
    const st = hud.tossSt, m = st && st.m;
    if (s === 'toss') return `<h2>PAR OU ÍMPAR</h2><p class="sub">${esc(tn(m, 0))} × ${esc(tn(m, 1))}</p><p class="sub">${st.kind === 'set3' ? 'Sorteio do set decisivo · ' : ''}Quem ganhar escolhe sacar ou receber · <b>${who(m, st.picker)}</b>, par ou ímpar?</p>`;
    if (s === 'toss-num') {
      const t = st.numFor, n = st.nums[t] ?? 0;
      return `<h2>PAR OU ÍMPAR</h2><p class="sub"><b>${who(m, st.picker)}</b>: ${st.pick === 'par' ? 'PAR' : 'ÍMPAR'} · <b>${who(m, t)}</b>, quantos dedos?</p><div class="toss-hands">${handSVG(n)}<b class="toss-n">${n}</b></div>`;
    }
    if (s === 'toss-show') {
      const sum = st.nums[0] + st.nums[1], w = st.winner;
      return `<h2>${sum % 2 === 0 ? 'PAR' : 'ÍMPAR'}!</h2><div class="toss-hands two"><figure>${handSVG(st.nums[0])}<figcaption>${esc(who(m, 0))} · ${st.nums[0]}</figcaption></figure><b class="toss-sum">${st.nums[0]} + ${st.nums[1]} = ${sum}</b><figure>${handSVG(st.nums[1], true)}<figcaption>${esc(who(m, 1))} · ${st.nums[1]}</figcaption></figure></div>
        <p class="sub"><b>${esc(tn(m, w))}</b> ${m.teams[w].human ? 'ganhou! Sacar ou receber?' : `ganhou e escolheu <b>${st.cpuChoice === 'sacar' ? 'sacar' : 'receber'}</b>.`}</p>`;
    }
    if (s === 'toss-choice') {
      const w = st.winner;
      return `<h2>SET ${m.setNo + 2} · ESCOLHA</h2><p class="sub"><b>${esc(tn(m, w))}</b> perdeu o sorteio do 1º set e agora escolhe${m.teams[w].human ? ': sacar ou receber?' : `: <b>${st.cpuChoice === 'sacar' ? 'sacar' : 'receber'}</b>.`}</p>`;
    }
    if (s === 'set-break') {
      const b = hud.setBreakSt, mm = b.m, last = mm.setHistory[mm.setHistory.length - 1] || [0, 0];
      return `<h2>FIM DO ${mm.setNo + 1}º SET</h2><p class="sub">${esc(tn(mm, 0))} <b>${last[0]} × ${last[1]}</b> ${esc(tn(mm, 1))}</p><p class="sub">Sets: <b>${mm.setsWon[0]} × ${mm.setsWon[1]}</b> · intervalo de 3 minutos · o próximo set vai até ${mm.setPoints[mm.setNo + 1]} pontos</p>`;
    }
    // ---------- campeonato ----------
    const c = hud.camp || loadCamp(), T = c.cur;
    if (s === 'camp') return `<h2>MODO CAMPEONATO</h2><p class="sub">Regras oficiais do futevôlei · 8 duplas · premiação no fim · carteira ${money(c.wallet)}</p>`;
    if (s === 'camp-new') return '<h2>NOVO CAMPEONATO</h2><p class="sub">Sua dupla e o nível das outras 7 duplas (sorteadas entre os atletas do jogo)</p>';
    if (s === 'camp-confirm') return `<h2>CAMPEONATO EM ANDAMENTO</h2><p class="sub">Começar outro abandona o atual (${esc(PHASE_NAME[T && T.stage] || '')}). Continuar?</p>`;
    if (s === 'camp-rules') {
      const C = CAMP(), f = formatOf('final');
      return `<h2>REGRAS OFICIAIS</h2><ul class="camp-rules">
        <li>Duplas, quadra de 18 × 9 m, rede de 2,20 m, máximo de 3 toques, sem tocar duas vezes seguidas.</li>
        <li>Grupos e semifinal: set único de ${formatOf('grupo').sets[0]} pontos, 2 de diferença; troca de lado a cada ${formatOf('grupo').swaps[0]} pontos.</li>
        <li>Final: melhor de 3 sets (${f.sets.join(', ')}); troca a cada ${f.swaps[0]} (e a cada ${f.swaps[2] || f.swaps[0]} no decisivo).</li>
        <li>${+(C.temposTecnicos ?? 1)} tempo técnico por dupla na partida (no menu de pausa, com a bola parada); troca de lado sem pausa.</li>
        <li>Par ou ímpar no início: quem ganha escolhe sacar ou receber; no 2º set escolhe quem perdeu; no 3º, novo sorteio.</li>
        <li>Tabela: vitória ${+((C.pontosTabela || {}).vitoria ?? 3)}, derrota ${+((C.pontosTabela || {}).derrota ?? 1)}. Desempate: confronto direto, saldo de sets, saldo de pontos, sorteio.</li>
        <li>Prêmios: ${(C.premios || []).map((p, i) => `${i + 1}º ${money(p)}`).join(' · ')}.</li></ul>`;
    }
    if (s === 'camp-table' && T) {
      const nm = nextMatch(T);
      const grp = gk => `<table class="camp-tbl"><caption>Grupo ${gk}</caption><tr><th>Dupla</th><th>J</th><th>V</th><th>Sets</th><th>Pts</th></tr>${standings(T, gk).map((r, i) => `<tr class="${r.id === 0 ? 'me' : ''} ${i < 2 ? 'up' : ''}"><td>${faces(T.teams[r.id].ids)}<span>${esc(short(T.teams[r.id].ids))}</span></td><td>${r.j}</td><td>${r.v}</td><td>${r.sg}-${r.sp}</td><td><b>${r.pts}</b></td></tr>`).join('')}</table>`;
      const ko = ph => T.matches.filter(x => x.phase === ph).map(x => `<div class="ko ${x.a === 0 || x.b === 0 ? 'me' : ''}"><small>${PHASE_NAME[ph]}</small><span>${faces(T.teams[x.a].ids)} ${esc(short(T.teams[x.a].ids))}</span><b>${x.winner === null ? '×' : x.sets.map(s2 => s2.join('-')).join(' / ')}</b><span>${esc(short(T.teams[x.b].ids))} ${faces(T.teams[x.b].ids)}</span></div>`).join('');
      const body = T.stage === 'grupo' ? `<div class="camp-groups">${grp('A')}${grp('B')}</div>` : `<div class="camp-ko">${ko('semi')}${ko('terceiro')}${ko('final')}</div>`;
      const next = nm ? `<p class="camp-next">Próxima: <b>${PHASE_NAME[nm.phase]}${nm.round ? ' · rodada ' + nm.round : ''}</b> · ${esc(short(T.teams[nm.a].ids))} × ${esc(short(T.teams[nm.b].ids))} · ${formatOf(nm.phase).sets.length > 1 ? 'melhor de 3 sets' : 'set único de ' + formatOf(nm.phase).sets[0]}</p>` : '';
      return `<h2>${esc(T.name)}</h2><p class="sub">${PHASE_NAME[T.stage] || 'Fim'} · sua dupla: ${faces(T.teams[0].ids)} ${esc(short(T.teams[0].ids))} · nível ${T.level}</p>${body}${next}`;
    }
    if (s === 'camp-result' && hud.campResult) {
      const r = hud.campResult;
      return `<h2>${r.wo ? 'W.O.' : r.won ? 'VITÓRIA!' : 'DERROTA...'}</h2><p class="sub">${PHASE_NAME[r.phase]} · ${esc(r.us)} × ${esc(r.them)}</p><p class="camp-sets">${r.sets.map((x, i) => `<span>${i + 1}º set <b>${x[0]} × ${x[1]}</b></span>`).join('')}</p>${r.out ? `<p class="sub">Sua dupla terminou em <b>${placeName(r.out)}</b>. O campeonato segue até a final.</p>` : ''}`;
    }
    if (s === 'camp-podium' && T && T.podium) {
      const col = (pos, cls) => { const id = T.podium[pos - 1]; const t = T.teams[id]; const prize = (CAMP().premios || [])[pos - 1]; return `<div class="pod ${cls} ${id === 0 ? 'me' : ''}"><span class="pod-medal">${medal(pos)}</span><span class="pod-faces">${faces(t.ids)}</span><b>${esc(short(t.ids))}</b><span class="pod-step">${pos}º</span><small>${prize ? money(prize) : ''}</small></div>`; };
      return `<h2>PREMIAÇÃO</h2><p class="sub">${esc(T.name)} · campeões: <b>${esc(teamName(T.teams[T.podium[0]]))}</b></p><div class="podium">${col(2, 'p2')}${col(1, 'p1')}${col(3, 'p3')}</div><p class="sub">Sua dupla: <b>${placeName(T.place)}</b>${T.prize ? ` · prêmio <b>${money(T.prize)}</b>` : ''} · carteira ${money(c.wallet)}</p>`;
    }
    if (s === 'camp-trophies') {
      const list = (c.trophies || []).slice(0, 6);
      return `<h2>SALA DE TROFÉUS</h2><p class="sub">Carteira: <b>${money(c.wallet)}</b> · ${(c.trophies || []).filter(t => t.place === 1).length} título(s)</p><div class="trophies">${list.length ? list.map(t => `<div class="tro ${t.place === 1 ? 'gold' : ''}"><span class="tro-ico">${medal(t.place) || '🎽'}</span><b>${placeName(t.place)}</b><span>${faces(t.dupla)} ${esc(short(t.dupla))}</span><small>${new Date(t.date).toLocaleDateString('pt-BR')} · ${t.prize ? money(t.prize) : 'sem prêmio'}</small></div>`).join('') : '<p class="sub">Nenhum campeonato terminado ainda.</p>'}</div>${(c.trophies || []).length > 6 ? `<p class="sub">+ ${(c.trophies || []).length - 6} mais antigos</p>` : ''}`;
    }
    if (s === 'camp-deposit') return `<h2>DEPOSITAR NO MODO HISTÓRIA</h2><p class="sub">Leva os ${money(c.wallet)} da carteira para um jogo salvo (a Giulia pode gastar nas lojas)</p>`;
    return null;
  };

  hud.extItems = s => {
    const st = hud.tossSt;
    if (s === 'toss') return [{ id: 'toss-par', html: 'Par' }, { id: 'toss-impar', html: 'Ímpar' }];
    if (s === 'toss-num') {
      const t = st.numFor;
      return [
        { type: 'choice', id: 'toss-n', label: 'Dedos', options: [0, 1, 2, 3, 4, 5].map(v => ({ value: v, html: String(v) })), value: st.nums[t] ?? 0,
          change: step => { st.nums[t] = ((st.nums[t] ?? 0) + step + 6) % 6; }, pick: v => { st.nums[t] = +v; } },
        { id: 'toss-num-go', html: 'Pronto!', nav: 'next' },
      ];
    }
    if (s === 'toss-show' || s === 'toss-choice') {
      return st && st.m.teams[st.winner].human ? [{ id: 'toss-sacar', html: 'Sacar<small>começa com a bola</small>' }, { id: 'toss-receber', html: 'Receber<small>a outra dupla saca</small>' }]
        : [{ id: 'toss-start', html: 'Começar!', nav: 'next' }];
    }
    if (s === 'set-break') return [{ id: 'set-go', html: 'Avançar', nav: 'next' }];
    // ---------- campeonato ----------
    const c = hud.camp || loadCamp(), T = c.cur;
    if (s === 'camp') return [
      ...(T && !T.done ? [{ id: 'camp-continue', html: `Continuar campeonato<small>${PHASE_NAME[T.stage]} · ${esc(short(T.teams[0].ids))}</small>` }] : []),
      ...(T && T.done && !T.seen ? [{ id: 'camp-podium', html: 'Ver a premiação<small>último campeonato</small>' }] : []),
      { id: 'camp-new', html: 'Novo campeonato<small>escolha a dupla e o nível</small>' },
      { id: 'camp-trophies', html: `Sala de troféus<small>carteira ${money(c.wallet)}</small>` },
      { id: 'camp-rules', html: 'Regras oficiais<small>como funciona</small>' },
      { id: 'back', html: 'Voltar' },
    ];
    if (s === 'camp-new') {
      const cfg = hud.campCfg, all = campAthletes();
      const pickAth = k => ({
        type: 'choice', id: 'ath' + k, label: `Atleta ${k + 1}`, value: cfg.ids[k],
        options: all.map(id => ({ value: id, html: `<img class="opt-face" src="${faceIcon(id)}" alt="">${esc((CHARACTERS[id] || {}).name || id)}` })),
        change: step => { let i = all.indexOf(cfg.ids[k]); do { i = (i + step + all.length) % all.length; } while (all[i] === cfg.ids[1 - k]); cfg.ids[k] = all[i]; },
        pick: v => { if (v !== cfg.ids[1 - k]) cfg.ids[k] = v; },
      });
      return [
        { type: 'choice', id: 'cplayers', label: 'Jogadores', value: cfg.players, options: [{ value: 1, html: '1 jogador' }, { value: 2, html: '2 juntos' }],
          change: () => { cfg.players = cfg.players === 1 ? 2 : 1; }, pick: v => { cfg.players = +v; } },
        pickAth(0), pickAth(1),
        { type: 'choice', id: 'clevel', label: 'Nível das duplas da CPU', value: cfg.level,
          options: Array.from({ length: MAX_LEVEL - MIN_LEVEL + 1 }, (_, i) => ({ value: MIN_LEVEL + i, html: `${MIN_LEVEL + i} · ${LEVEL_NAMES[i]}` })),
          change: step => { cfg.level = Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, cfg.level + step)); }, pick: v => { cfg.level = +v; } },
        { id: 'back', html: 'Voltar' },
        { id: 'camp-go', html: 'Pronto!', nav: 'next' },
      ];
    }
    if (s === 'camp-confirm') return [{ id: 'back', html: 'Voltar' }, { id: 'camp-start', html: 'Começar outro', nav: 'next' }];
    if (s === 'camp-rules' || s === 'camp-trophies') return [{ id: 'back', html: 'Voltar' }];
    if (s === 'camp-table') return [
      { id: 'camp-home', html: 'Sair<small>o campeonato fica salvo</small>', nav: 'back' },
      ...(T && nextMatch(T) ? [{ id: 'camp-play', html: 'Jogar!', nav: 'next' }] : T && T.done ? [{ id: 'camp-podium', html: 'Premiação', nav: 'next' }] : []),
    ];
    if (s === 'camp-result') return [{ id: 'camp-next', html: 'Avançar', nav: 'next' }];
    if (s === 'camp-podium') return [
      ...(c.wallet > 0 && SLOTS.some(n => !slotLabel(n).empty) ? [{ id: 'camp-deposit', html: `Depositar no Modo História<small>${money(c.wallet)}</small>` }] : []),
      { id: 'camp-trophies', html: 'Sala de troféus' },
      { id: 'camp-home', html: 'Pronto!', nav: 'next' },
    ];
    if (s === 'camp-deposit') return [
      ...SLOTS.map(n => { const l = slotLabel(n); return l.empty ? { id: 'noop', html: `Vaga ${n}<small>vazia</small>`, cls: 'off' } : { id: 'dep:' + n, html: `Vaga ${n}<small>${esc(l.text)}</small>` }; }),
      { id: 'back', html: 'Voltar' },
    ];
    return null;
  };

  hud.extClass = s => (['camp-table', 'camp-podium', 'camp-trophies', 'camp-rules', 'camp-new'].includes(s) ? 'wide' : '') + (s === 'camp-trophies' ? '' : '');

  hud.extActivate = id => {
    const st = hud.tossSt;
    if (/^toss-/.test(id) && !st) return true; // sorteio já fechado: ignora
    if (id === 'toss-par' || id === 'toss-impar') {
      st.pick = id === 'toss-par' ? 'par' : 'impar';
      st.order = tossNumOrder(st); st.numFor = st.order[0]; st.nums[st.numFor] = st.nums[st.numFor] ?? 0;
      hud.open('toss-num'); return true;
    }
    if (id === 'toss-num-go') {
      const i = st.order.indexOf(st.numFor);
      if (i < st.order.length - 1) { st.numFor = st.order[i + 1]; st.nums[st.numFor] = st.nums[st.numFor] ?? 0; hud.open('toss-num'); }
      else resolveToss();
      return true;
    }
    if (id === 'toss-sacar' || id === 'toss-receber') { finishToss(id === 'toss-sacar' ? 'sacar' : 'receber'); return true; }
    if (id === 'toss-start') { finishToss(st.cpuChoice || 'sacar'); return true; }
    if (id === 'set-go') { const b = hud.setBreakSt; hud.setBreakSt = null; hud.close(); b.onDone(); return true; }
    // ---------- campeonato ----------
    if (id === 'camp') { hud.camp = loadCamp(); hud.push('camp'); return true; }
    if (id === 'camp-new') {
      const all = campAthletes(), last = settings.campDupla || [];
      const a = all.includes(last[0]) ? last[0] : all[0], b = all.includes(last[1]) && last[1] !== a ? last[1] : all.find(x => x !== a);
      hud.campCfg = { players: settings.campPlayers || 1, ids: [a, b], level: settings.campLevel || 5 };
      hud.push('camp-new'); return true;
    }
    if (id === 'camp-go') {
      const cfg = hud.campCfg; settings.campDupla = [...cfg.ids]; settings.campPlayers = cfg.players; settings.campLevel = cfg.level; saveSettings();
      const T = (hud.camp || loadCamp()).cur;
      if (T && !T.done) { hud.push('camp-confirm'); return true; }
      hud.actions.campNew(cfg); return true;
    }
    if (id === 'camp-start') { hud.actions.campNew(hud.campCfg); return true; }
    if (id === 'camp-continue') { hud.actions.campTable(); return true; }
    if (id === 'camp-rules' || id === 'camp-trophies' || id === 'camp-deposit') { hud.camp = loadCamp(); hud.push(id); return true; }
    if (id === 'camp-play') { hud.close(); hud.actions.campPlay(); return true; }
    if (id === 'camp-next') { hud.actions.campAfterResult(); return true; }
    if (id === 'camp-podium') { hud.actions.campPodium(); return true; }
    if (id === 'camp-home') { hud.actions.campHome(); return true; }
    if (id.startsWith('dep:')) { hud.actions.campDeposit(+id.slice(4)); return true; }
    if (id === 'noop') return true;
    if (id === 'tempo') { hud.actions.campTempo(); return true; }
    if (id === 'camp-wo') { hud.actions.campWO(); return true; }
    return false;
  };
}

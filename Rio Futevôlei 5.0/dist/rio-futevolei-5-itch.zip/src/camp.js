// 5.0 Modo Campeonato — regras oficiais do futevôlei (CBFv / FIFv), editáveis em src/data/partida5.js
// (campeonato; editor da Partida → aba Campeonato):
//   8 duplas em 2 grupos de 4 (todos contra todos, set único de 18 pontos com 2 de diferença, troca de lado a
//   cada 6 pontos somados) → semifinal (1º A × 2º B e 1º B × 2º A, set único) → disputa de 3º lugar (set único)
//   e final em melhor de 3 sets (18, 18 e 15; troca de lado a cada 6, e a cada 5 no set decisivo).
//   Tabela dos grupos: vitória 3 pontos, derrota 1. Desempate: confronto direto (2 empatadas), saldo de sets
//   (sets ganhos ÷ perdidos), saldo de pontos (pontos feitos ÷ sofridos), sorteio.
//   1 tempo técnico por dupla em cada partida. Premiação: troféu (1º), medalhas (1º, 2º, 3º) e R$ na carteira.
// O jogador joga as partidas da sua dupla; as outras são simuladas (força pelos níveis e atributos).
import { V5 } from './v5.js';
import { CHARACTERS, ROSTER } from './art/characters.js';
import { listCustom } from './art/custom.js';
import { MIN_LEVEL, MAX_LEVEL } from './difficulty.js';
import ATHLETES from './data/athletes.js';
import './story/data.js'; // registra os atletas do Modo História (as duplas dos bairros)

const KEY = 'rio-futevolei.camp';
export const CAMP = () => V5.campeonato || {};

// ---------- salvo: carteira, troféus e o campeonato em andamento ----------
export function loadCamp() {
  try { const c = JSON.parse(localStorage.getItem(KEY) || 'null'); if (c && c.v === 1) return c; } catch { /* sem armazenamento */ }
  return { v: 1, wallet: 0, trophies: [], cur: null };
}
export function saveCamp(c) { try { localStorage.setItem(KEY, JSON.stringify(c)); return true; } catch { return false; } }

// todos os atletas que podem jogar (os do jogo e os criados)
export function campAthletes() {
  return [...ROSTER, ...listCustom().map(r => r.id)].filter(id => id && CHARACTERS[id]);
}
const shuffle = (a, rnd = Math.random) => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const clampLv = v => Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, Math.round(v)));
export const teamName = t => t.ids.map(id => (CHARACTERS[id] || { name: id }).name).join(' & ');

// formato de cada fase: { sets: [pontos...], swaps: [troca de lado...] }
export function formatOf(phase) {
  const C = CAMP();
  if (phase === 'final') { const f = C.final || {}; return { sets: (f.sets || [18, 18, 15]).map(Number), swaps: (f.trocaLado || [6, 6, 5]).map(Number) }; }
  const g = C[phase === 'grupo' ? 'grupos' : phase === 'semi' ? 'semifinal' : 'terceiro'] || {};
  return { sets: [+(g.pontos || 18)], swaps: [+(g.trocaLado || 6)] };
}
export const PHASE_NAME = { grupo: 'Fase de grupos', semi: 'Semifinal', terceiro: 'Disputa de 3º lugar', final: 'Final' };

// ---------- campeonato novo ----------
// cfg = { ids: [atleta1, atleta2], level, players: 1 | 2, specials }
export function newTournament(cfg) {
  const C = CAMP(), varN = +(C.nivelVariacao ?? 2);
  const teams = [{ id: 0, ids: [...cfg.ids], human: true, level: cfg.level }];
  // 7 duplas da CPU, sem repetir atleta: as duplas dos bairros do Modo História (editor de Atletas) e pares
  // formados com os atletas da grade que sobraram
  const free = id => id && CHARACTERS[id] && !cfg.ids.includes(id);
  const story = Object.values((ATHLETES && ATHLETES.teams) || {}).filter(t => t.length === 2 && t.every(free));
  const left = shuffle(campAthletes().filter(free));
  const pairs = []; for (let i = 0; i + 1 < left.length; i += 2) pairs.push([left[i], left[i + 1]]);
  const pick = shuffle([...story, ...pairs]).slice(0, 7);
  pick.forEach((ids, i) => teams.push({ id: i + 1, ids: [...ids], human: false, level: clampLv(cfg.level + Math.round((Math.random() * 2 - 1) * varN)) }));
  const order = shuffle([1, 2, 3, 4, 5, 6, 7]);
  const groups = { A: [0, order[0], order[1], order[2]], B: [order[3], order[4], order[5], order[6]] };
  const matches = [];
  // todos contra todos em cada grupo: 3 rodadas, 2 jogos por grupo em cada rodada
  const rr = g => [[[g[0], g[1]], [g[2], g[3]]], [[g[0], g[2]], [g[1], g[3]]], [[g[0], g[3]], [g[1], g[2]]]];
  for (const gk of ['A', 'B']) rr(groups[gk]).forEach((round, r) => round.forEach(([a, b]) => matches.push({ id: matches.length, phase: 'grupo', group: gk, round: r + 1, a, b, sets: [], winner: null })));
  return {
    name: C.nome || 'Campeonato Rio Futevôlei', created: Date.now(), players: cfg.players || 1, level: cfg.level,
    specials: cfg.specials || null, teams, groups, matches, stage: 'grupo', done: false, place: null, podium: null, prize: 0,
  };
}

// ---------- tabela dos grupos (critérios oficiais) ----------
export function standings(T, gk) {
  const ids = T.groups[gk], P = (CAMP().pontosTabela || {}), V = +(P.vitoria ?? 3), D = +(P.derrota ?? 1);
  const row = id => ({ id, j: 0, v: 0, d: 0, sg: 0, sp: 0, pf: 0, pc: 0, pts: 0 });
  const rows = Object.fromEntries(ids.map(id => [id, row(id)]));
  const played = T.matches.filter(m => m.phase === 'grupo' && m.group === gk && m.winner !== null);
  for (const m of played) {
    for (const [me, op, k] of [[m.a, m.b, 0], [m.b, m.a, 1]]) {
      const r = rows[me]; r.j++;
      const win = m.winner === me; if (win) { r.v++; r.pts += V; } else { r.d++; r.pts += D; }
      for (const s of m.sets) { const mine = s[k], theirs = s[1 - k]; r.pf += mine; r.pc += theirs; if (mine > theirs) r.sg++; else r.sp++; }
    }
  }
  const avg = (a, b) => (b ? a / b : a ? Infinity : 0);
  const list = Object.values(rows);
  // sorteio fixo por campeonato (desempate final)
  const lot = id => ((T.created + id * 7919) % 1000) / 1000;
  list.sort((x, y) => {
    if (y.pts !== x.pts) return y.pts - x.pts;
    const tied = list.filter(r => r.pts === x.pts);
    if (tied.length === 2) { const h = played.find(m => (m.a === x.id && m.b === y.id) || (m.a === y.id && m.b === x.id)); if (h) return h.winner === x.id ? -1 : 1; }
    const sx = avg(x.sg, x.sp), sy = avg(y.sg, y.sp); if (sy !== sx) return sy - sx;
    const px = avg(x.pf, x.pc), py = avg(y.pf, y.pc); if (py !== px) return py - px;
    return lot(y.id) - lot(x.id);
  });
  return list;
}

// ---------- próxima partida do jogador ----------
export function nextMatch(T) {
  return T.matches.find(m => m.winner === null && (m.a === 0 || m.b === 0)) || null;
}

// ---------- simulação das partidas da CPU ----------
function strength(T, id) {
  const t = T.teams[id];
  const st = t.ids.map(a => (CHARACTERS[a] || {}).stats || {}).reduce((s, x) => s + (x.forca || 5) + (x.agilidade || 5) + (x.precisao || 5) + (x.pique || 5), 0) / t.ids.length / 4;
  return t.level * 1.0 + (st - 6) * 0.6;
}
export function simulate(T, m) {
  const { sets } = formatOf(m.phase);
  const p = Math.max(0.25, Math.min(0.75, 0.5 + (strength(T, m.a) - strength(T, m.b)) * 0.025));
  const won = [0, 0], need = Math.ceil(sets.length / 2);
  m.sets = [];
  for (const pts of sets) {
    let a = 0, b = 0;
    while (!((a >= pts || b >= pts) && Math.abs(a - b) >= 2)) { if (Math.random() < p) a++; else b++; }
    m.sets.push([a, b]); won[a > b ? 0 : 1]++;
    if (won[0] >= need || won[1] >= need) break;
  }
  m.winner = won[0] > won[1] ? m.a : m.b;
}

// ---------- resultado de uma partida do jogador e avanço de fase ----------
// sets = [[pontos da dupla a, pontos da b], ...] na ordem a/b da partida
export function recordResult(T, m, sets) {
  m.sets = sets.map(s => [...s]);
  const won = [0, 0]; for (const s of sets) won[s[0] > s[1] ? 0 : 1]++;
  m.winner = won[0] > won[1] ? m.a : m.b;
  // as outras partidas da mesma rodada / fase são simuladas
  for (const o of T.matches) if (o.winner === null && o.phase === m.phase && (o.phase !== 'grupo' || o.round === m.round) && o !== m && o.a !== 0 && o.b !== 0) simulate(T, o);
  advance(T);
}
// simula tudo o que falta (jogador eliminado: o campeonato termina sem ele)
export function simulateRest(T) {
  for (let guard = 0; guard < 20 && !T.done; guard++) {
    const open = T.matches.filter(m => m.winner === null);
    if (!open.length) { advance(T); continue; }
    if (open.some(m => m.a === 0 || m.b === 0)) break;
    open.forEach(m => simulate(T, m));
    advance(T);
  }
}
export function advance(T) {
  const open = T.matches.filter(m => m.winner === null);
  if (open.length) {
    // jogador fora da fase atual: o resto da fase é simulado
    if (!open.some(m => m.a === 0 || m.b === 0)) { open.forEach(m => simulate(T, m)); }
    else return;
  }
  const add = (phase, a, b) => T.matches.push({ id: T.matches.length, phase, a, b, sets: [], winner: null });
  if (T.stage === 'grupo') {
    const A = standings(T, 'A'), B = standings(T, 'B');
    T.groupPlace = {};
    A.forEach((r, i) => { T.groupPlace[r.id] = i + 1; }); B.forEach((r, i) => { T.groupPlace[r.id] = i + 1; });
    add('semi', A[0].id, B[1].id); add('semi', B[0].id, A[1].id);
    T.stage = 'semi';
    if (![A[0], A[1], B[0], B[1]].some(r => r.id === 0)) { T.place = T.groupPlace[0] === 3 ? 5 : 7; }
    return advance(T);
  }
  if (T.stage === 'semi') {
    const semis = T.matches.filter(m => m.phase === 'semi');
    const lose = m => (m.winner === m.a ? m.b : m.a);
    add('terceiro', lose(semis[0]), lose(semis[1]));
    add('final', semis[0].winner, semis[1].winner);
    T.stage = 'final';
    return advance(T);
  }
  if (T.stage === 'final') {
    const fin = T.matches.find(m => m.phase === 'final'), ter = T.matches.find(m => m.phase === 'terceiro');
    const lose = m => (m.winner === m.a ? m.b : m.a);
    T.podium = [fin.winner, lose(fin), ter.winner, lose(ter)];
    const at = T.podium.indexOf(0);
    if (at >= 0) T.place = at + 1;
    const prizes = (CAMP().premios || [300, 150, 80]).map(Number);
    T.prize = T.place && T.place <= prizes.length ? prizes[T.place - 1] : 0;
    T.stage = 'fim'; T.done = true;
  }
}

// ---------- fim: troféu e dinheiro ----------
export function finish(c) {
  const T = c.cur;
  if (!T || !T.done || T.paid) return;
  T.paid = true;
  c.wallet = (c.wallet || 0) + (T.prize || 0);
  c.trophies = [{ name: T.name, date: Date.now(), dupla: T.teams[0].ids, place: T.place, prize: T.prize || 0, champion: T.podium ? T.podium[0] : null, champIds: T.podium ? T.teams[T.podium[0]].ids : [] }, ...(c.trophies || [])].slice(0, 30);
}
export const placeName = n => (n ? `${n}º lugar` : '—');
export const medal = n => ['🏆', '🥈', '🥉'][n - 1] || '';
